package com.gildedrose;

class GildedRose {
    Item[] items;

    public GildedRose(Item[] items) {
        this.items = items;
    }

    public void updateQuality() {
        for (int i = 0; i < items.length; i++) {

            switch (items[i].name) {
                case "Aged Brie":

                    if (items[i].quality < 50) {
                        items[i].quality = items[i].quality + 1;
                    }

                    if (items[i].quality < 50) {
                        if (items[i].sellIn < 0) {
                            items[i].quality = items[i].quality + 1;
                        }
                    }
                    break;

                case "Sulfuras, Hand of Ragnaros":
                    break;

                case "Backstage passes to a TAFKAL80ERC concert":
                    if (items[i].quality < 50) {
                        items[i].quality = items[i].quality + 1;

                        if (items[i].sellIn < 11) {
                            if (items[i].quality < 50) {
                                items[i].quality = items[i].quality + 1;
                            }
                        }

                        if (items[i].sellIn < 6) {
                            if (items[i].quality < 50) {
                                items[i].quality = items[i].quality + 1;
                            }
                        }
                    }

                    items[i].sellIn = items[i].sellIn - 1;

                    if (items[i].sellIn < 0) {
                        items[i].quality = 0;
                    }
                    break;

                case "Conjured Mana Cake":
                    if (items[i].quality < 50) {
                        items[i].quality = items[i].quality + 1;
                    }

                    items[i].sellIn = items[i].sellIn - 2;

                    break;

                default:
                    items[i].sellIn = items[i].sellIn - 1;

                    if (items[i].quality > 0) {
                        items[i].quality = items[i].quality - 1;
                    }

                    if (items[i].sellIn < 0) {
                        if (items[i].quality > 0) {
                            items[i].quality = items[i].quality - 1;
                        }
                    }
                    break;
            }
        }
    }
}

